package com.kidsshell

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*

fun Activity.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

fun Activity.askPin(onOk: () -> Unit) {
    val act = this
    val et = EditText(act).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        hint = "קוד"
    }
    val first = !Store.hasPin(act)
    AlertDialog.Builder(act)
        .setTitle(if (first) "הגדרת קוד הורה חדש (לפחות 4 ספרות)" else "קוד הורה")
        .setView(et)
        .setPositiveButton("אישור") { _, _ ->
            val v = et.text.toString()
            if (first) {
                if (v.length >= 4) { Store.setPin(act, v); onOk() } else act.toast("לפחות 4 ספרות")
            } else if (Store.checkPin(act, v)) onOk() else act.toast("קוד שגוי")
        }
        .setNegativeButton("ביטול", null)
        .show()
}

class MainActivity : Activity() {
    override fun onResume() {
        super.onResume()
        build()
        if (Store.lock(this)) try { startLockTask() } catch (e: Exception) { }
    }

    private fun build() {
        val act = this
        val root = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        root.addView(TextView(act).apply { text = "האפליקציות שלי"; textSize = 26f; gravity = Gravity.CENTER })
        Store.apps(act).forEach { app ->
            root.addView(Button(act).apply {
                text = app.name
                textSize = 20f
                setOnClickListener { act.startActivity(Intent(act, WebActivity::class.java).putExtra("id", app.id)) }
            })
        }
        root.addView(Button(act).apply {
            text = "⚙ הורים"
            setOnClickListener { act.askPin { act.startActivity(Intent(act, ParentActivity::class.java)) } }
        })
        act.setContentView(ScrollView(act).apply { addView(root) })
    }
}

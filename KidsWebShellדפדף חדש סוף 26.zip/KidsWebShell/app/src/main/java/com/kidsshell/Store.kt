package com.kidsshell

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

data class WebApp(val id: String, val name: String, val type: String, val src: String)

object Store {
    const val HOST = "appassets.androidplatform.net"
    private fun p(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun apps(c: Context): MutableList<WebApp> {
        val s = p(c).getString("apps", null)
        if (s == null) {
            val d = mutableListOf(WebApp("voice", "מקול לכלי נגינה", "asset", "voice.html"))
            save(c, d)
            return d
        }
        val a = JSONArray(s)
        val out = mutableListOf<WebApp>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(WebApp(o.getString("id"), o.getString("name"), o.getString("type"), o.getString("src")))
        }
        return out
    }

    fun save(c: Context, l: List<WebApp>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("type", it.type).put("src", it.src)) }
        p(c).edit().putString("apps", a.toString()).apply()
    }

    fun urlOf(w: WebApp): String = when (w.type) {
        "asset" -> "https://$HOST/assets/${w.src}"
        "file" -> "https://$HOST/apps/${w.src}"
        else -> w.src
    }

    private fun hash(pin: String): String =
        MessageDigest.getInstance("SHA-256").digest(("kids$pin").toByteArray()).joinToString("") { "%02x".format(it) }

    fun hasPin(c: Context) = p(c).contains("pin")
    fun setPin(c: Context, pin: String) { p(c).edit().putString("pin", hash(pin)).apply() }
    fun checkPin(c: Context, pin: String) = p(c).getString("pin", null) == hash(pin)
    fun lock(c: Context) = p(c).getBoolean("lock", false)
    fun setLock(c: Context, v: Boolean) { p(c).edit().putBoolean("lock", v).apply() }
    fun appsDir(c: Context): File = File(c.filesDir, "apps").also { it.mkdirs() }
}

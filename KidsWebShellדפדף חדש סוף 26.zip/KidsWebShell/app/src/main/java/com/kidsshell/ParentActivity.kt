package com.kidsshell

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.*
import java.io.File
import java.util.UUID

class ParentActivity : Activity() {
    private lateinit var apps: MutableList<WebApp>

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        apps = Store.apps(this)
        render()
    }

    private fun render() {
        val act = this
        val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        root.addView(TextView(act).apply { text = "הגדרות הורים"; textSize = 24f })
        apps.toList().forEach { a ->
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(TextView(act).apply { text = a.name; textSize = 18f }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(act).apply {
                text = "מחק"
                setOnClickListener {
                    apps.remove(a)
                    Store.save(act, apps)
                    if (a.type == "file") File(Store.appsDir(act), a.src).delete()
                    render()
                }
            })
            root.addView(row)
        }
        root.addView(Button(act).apply { text = "הוספת אתר (כתובת https)"; setOnClickListener { addUrl() } })
        root.addView(Button(act).apply {
            text = "ייבוא דף HTML מהמכשיר"
            setOnClickListener {
                act.startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 1)
            }
        })
        root.addView(Button(act).apply { text = "שינוי קוד הורה"; setOnClickListener { changePin() } })
        root.addView(CheckBox(act).apply {
            text = "נעילת מסך (הצמדת מסך) כשהאפליקציה פתוחה"
            isChecked = Store.lock(act)
            setOnCheckedChangeListener { _, c ->
                Store.setLock(act, c)
                if (!c) try { act.stopLockTask() } catch (e: Exception) { }
            }
        })
        root.addView(Button(act).apply { text = "סגירה"; setOnClickListener { act.finish() } })
        act.setContentView(ScrollView(act).apply { addView(root) })
    }

    private fun addUrl() {
        val act = this
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 16, 32, 0) }
        val n = EditText(act).apply { hint = "שם" }
        val u = EditText(act).apply { hint = "https://..."; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI }
        box.addView(n); box.addView(u)
        AlertDialog.Builder(act).setTitle("הוספת אתר").setView(box)
            .setPositiveButton("הוסף") { _, _ ->
                val url = u.text.toString().trim()
                if (!url.startsWith("https://")) { act.toast("הכתובת חייבת להתחיל ב-https://"); return@setPositiveButton }
                apps.add(WebApp(UUID.randomUUID().toString().take(8), n.text.toString().ifBlank { url }, "url", url))
                Store.save(act, apps); render()
            }.setNegativeButton("ביטול", null).show()
    }

    private fun changePin() {
        val act = this
        val et = EditText(act).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD; hint = "קוד חדש" }
        AlertDialog.Builder(act).setTitle("קוד הורה חדש").setView(et)
            .setPositiveButton("שמור") { _, _ ->
                val v = et.text.toString()
                if (v.length >= 4) { Store.setPin(act, v); act.toast("הקוד עודכן") } else act.toast("לפחות 4 ספרות")
            }.setNegativeButton("ביטול", null).show()
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        val uri = d?.data
        if (rc != 1 || res != RESULT_OK || uri == null) return
        val act = this
        val et = EditText(act).apply { setText("דף חדש") }
        AlertDialog.Builder(act).setTitle("שם לאפליקציה").setView(et)
            .setPositiveButton("שמור") { _, _ ->
                try {
                    val id = UUID.randomUUID().toString().take(8)
                    act.contentResolver.openInputStream(uri)!!.use { i ->
                        File(Store.appsDir(act), "$id.html").outputStream().use { o -> i.copyTo(o) }
                    }
                    apps.add(WebApp(id, et.text.toString().ifBlank { "דף" }, "file", "$id.html"))
                    Store.save(act, apps); render()
                } catch (e: Exception) { act.toast("הייבוא נכשל") }
            }.setNegativeButton("ביטול", null).show()
    }
}

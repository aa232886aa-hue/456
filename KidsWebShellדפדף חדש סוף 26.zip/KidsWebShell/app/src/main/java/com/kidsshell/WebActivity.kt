package com.kidsshell

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.webkit.*
import androidx.webkit.WebViewAssetLoader
import java.io.OutputStream

class Bridge(private val a: Activity) {
    private var out: OutputStream? = null
    private var uri: Uri? = null

    @JavascriptInterface
    fun begin(name: String, mime: String): Boolean = try {
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        uri = a.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
        out = a.contentResolver.openOutputStream(uri!!)
        true
    } catch (e: Exception) { false }

    @JavascriptInterface
    fun chunk(b64: String): Boolean = try { out!!.write(Base64.decode(b64, Base64.DEFAULT)); true } catch (e: Exception) { false }

    @JavascriptInterface
    fun end(): Boolean = try {
        out?.close(); out = null
        val v = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
        a.contentResolver.update(uri!!, v, null, null)
        a.runOnUiThread { a.toast("נשמר בתיקיית ההורדות") }
        true
    } catch (e: Exception) { false }
}

class WebActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingPerm: PermissionRequest? = null
    private var allowedHost = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val act = this
        val app = Store.apps(act).firstOrNull { it.id == intent.getStringExtra("id") }
        if (app == null) { finish(); return }
        val url = Store.urlOf(app)
        allowedHost = Uri.parse(url).host ?: ""
        val loader = WebViewAssetLoader.Builder().setDomain(Store.HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(act))
            .addPathHandler("/apps/", WebViewAssetLoader.InternalStoragePathHandler(act, Store.appsDir(act)))
            .build()
        web = WebView(act)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
        }
        web.addJavascriptInterface(Bridge(act), "AndroidBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == allowedHost) return false
                act.toast("הדף הזה לא מאושר")
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(r: PermissionRequest) {
                act.runOnUiThread {
                    val audio = r.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    if (r.origin.host != allowedHost || !audio) { r.deny(); return@runOnUiThread }
                    if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        r.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                    } else {
                        pendingPerm = r
                        act.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
                    }
                }
            }

            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, p: WebChromeClient.FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try { act.startActivityForResult(p.createIntent(), 5); true }
                catch (e: Exception) { fileCb = null; false }
            }
        }
        act.setContentView(web)
        web.loadUrl(url)
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc == 5) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d))
            fileCb = null
        } else super.onActivityResult(rc, res, d)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, g: IntArray) {
        if (rc == 7) {
            val r = pendingPerm; pendingPerm = null
            if (g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED) r?.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else r?.deny()
        } else super.onRequestPermissionsResult(rc, p, g)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onPause() { web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
